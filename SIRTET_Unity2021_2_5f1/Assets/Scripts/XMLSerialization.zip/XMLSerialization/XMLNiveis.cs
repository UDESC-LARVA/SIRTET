using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

[XmlRoot("Nivel")]
public class LevelInFile
{
	[XmlAttribute("Indice")]
	public int Id {get;set;}
	[XmlElement("Fase")]
	public string Phase {get;set;}
	[XmlElement("Velocidade")]
	public string Velocity {get;set;}
	[XmlElement("Tempo_Intervalo")]
	public string IntermissionTime {get;set;}
	[XmlElement("Tempo_Permanencia")]
	public string StayTime {get;set;}
}

[XmlRoot("Arquivo_de_Niveis")]
public class ListaNiveis
{

	[XmlArrayItem("Nivel", typeof(LevelInFile))]
	[XmlArray("Lista_Niveis")]
	public List<LevelInFile> listaNiveis;
	
	public ListaNiveis()
	{
		listaNiveis = new List<LevelInFile>();
	}
	
	public void Create()
	{
		ListaNiveis niveis = new ListaNiveis();
		
		niveis.listaNiveis.Add(new LevelInFile{ 
			Id = 1,
			Phase = "A",
			Velocity = "MIN",
			IntermissionTime = "MAX"
		});
		niveis.listaNiveis.Add(new LevelInFile{ 
			Id = 2,
			Phase = "A",
			Velocity = "MIN",
			IntermissionTime = "MED"
		});
		niveis.listaNiveis.Add(new LevelInFile{ 
			Id = 3,
			Phase = "A",
			Velocity = "MED",
			IntermissionTime = "MIN"
		});
		niveis.listaNiveis.Add(new LevelInFile{ 
			Id = 1,
			Phase = "B",
			Velocity = "MED",
			IntermissionTime = "MAX"
		});
		niveis.listaNiveis.Add(new LevelInFile{ 
			Id = 2,
			Phase = "B",
			Velocity = "MAX",
			IntermissionTime = "MED"
		});
		niveis.listaNiveis.Add(new LevelInFile{ 
			Id = 3,
			Phase = "B",
			Velocity = "MAX",
			IntermissionTime = "MIN"
		});
		
		XmlSerializer serializer = new XmlSerializer(niveis.GetType());
		using (StreamWriter writer = new StreamWriter(@"XML/Niveis.xml"))
		{
		    serializer.Serialize(writer, niveis);
		}	
	}
	
	public ListaNiveis Load()
	{
		ListaNiveis niveis = new ListaNiveis();
		XmlSerializer serializer = new XmlSerializer(niveis.GetType());
		StreamReader reader = new StreamReader("XML/Niveis.xml");
		niveis = (ListaNiveis)serializer.Deserialize(reader);
		reader.Close();
		return niveis;
	}
	
}